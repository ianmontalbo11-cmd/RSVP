CREATE TABLE IF NOT EXISTS rsvp_submissions (
  id BIGSERIAL PRIMARY KEY,
  submission_token UUID NOT NULL UNIQUE,
  guest_name VARCHAR(120) NOT NULL,
  email VARCHAR(254),
  attendance VARCHAR(16) NOT NULL CHECK (attendance IN ('accepts', 'declines')),
  guest_count SMALLINT NOT NULL DEFAULT 1 CHECK (guest_count BETWEEN 0 AND 10),
  companion_names TEXT,
  dietary_notes TEXT,
  message TEXT,
  source_page VARCHAR(255),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_rsvp_created_at ON rsvp_submissions (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_rsvp_attendance ON rsvp_submissions (attendance);
CREATE INDEX IF NOT EXISTS idx_rsvp_guest_name_lower ON rsvp_submissions (LOWER(guest_name));

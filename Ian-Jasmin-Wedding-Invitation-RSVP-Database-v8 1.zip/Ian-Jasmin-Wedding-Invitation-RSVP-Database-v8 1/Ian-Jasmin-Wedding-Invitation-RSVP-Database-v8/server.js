'use strict';

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { Pool } = require('pg');

const PORT = Number(process.env.PORT || 3000);
const PUBLIC_DIR = path.join(__dirname, 'public');
const DATABASE_URL = process.env.DATABASE_URL;
const ADMIN_KEY = process.env.ADMIN_KEY || '';
const PUBLIC_URL = process.env.PUBLIC_URL || '';
const MAX_BODY_BYTES = 20 * 1024;
const RATE_WINDOW_MS = 10 * 60 * 1000;
const RATE_MAX = 10;
const rateBuckets = new Map();

if (!DATABASE_URL) {
  console.error('DATABASE_URL is required. See .env.example or docker-compose.yml.');
  process.exit(1);
}
if (process.env.NODE_ENV === 'production' && ADMIN_KEY.length < 24) {
  console.error('ADMIN_KEY must be at least 24 characters in production.');
  process.exit(1);
}

const ssl = process.env.PGSSL === 'disable'
  ? false
  : process.env.NODE_ENV === 'production'
    ? { rejectUnauthorized: false }
    : false;
const pool = new Pool({ connectionString: DATABASE_URL, ssl, max: 10, idleTimeoutMillis: 30000 });

const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp',
  '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8'
};

function securityHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('Content-Security-Policy', "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; frame-ancestors 'self'; base-uri 'self'; form-action 'self'");
}

function json(res, status, payload) {
  securityHeaders(res);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(payload));
}

function cleanText(value, max) {
  if (value === undefined || value === null) return '';
  return String(value).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').trim().slice(0, max);
}

function normalizeAttendance(value) {
  const v = cleanText(value, 40).toLowerCase();
  if (v.includes('accept') || v.includes('joyfully') || v === 'yes') return 'accepts';
  if (v.includes('declin') || v.includes('regret') || v === 'no') return 'declines';
  return '';
}

function validateEmail(value) {
  if (!value) return true;
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) && value.length <= 254;
}

function getClientKey(req) {
  const forwarded = cleanText(req.headers['x-forwarded-for'], 200).split(',')[0].trim();
  return forwarded || req.socket.remoteAddress || 'unknown';
}

function checkRateLimit(req) {
  const now = Date.now();
  const key = getClientKey(req);
  const current = rateBuckets.get(key);
  if (!current || now - current.start > RATE_WINDOW_MS) {
    rateBuckets.set(key, { start: now, count: 1 });
    return true;
  }
  current.count += 1;
  return current.count <= RATE_MAX;
}

function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', chunk => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        reject(Object.assign(new Error('Request body is too large.'), { status: 413 }));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'));
      } catch {
        reject(Object.assign(new Error('Invalid JSON body.'), { status: 400 }));
      }
    });
    req.on('error', reject);
  });
}

function requireAdmin(req, res) {
  if (!ADMIN_KEY) {
    json(res, 503, { error: 'Admin access is not configured.' });
    return false;
  }
  const supplied = cleanText(req.headers['x-admin-key'], 512);
  const a = Buffer.from(supplied);
  const b = Buffer.from(ADMIN_KEY);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    json(res, 401, { error: 'Invalid admin key.' });
    return false;
  }
  return true;
}

async function initDatabase() {
  const schema = fs.readFileSync(path.join(__dirname, 'database', 'schema.sql'), 'utf8');
  await pool.query(schema);
  console.log('RSVP database schema is ready.');
}

async function submitRsvp(req, res) {
  if (!checkRateLimit(req)) return json(res, 429, { error: 'Too many submissions. Please wait and try again.' });
  const body = await readJsonBody(req);
  if (cleanText(body.company, 100)) return json(res, 201, { ok: true, confirmationCode: 'IJ-THANKYOU' });

  const guestName = cleanText(body.name, 120);
  const email = cleanText(body.email, 254).toLowerCase();
  const attendance = normalizeAttendance(body.attendance);
  const guestCountRaw = Number.parseInt(body.guests, 10);
  const guestCount = attendance === 'declines' ? 0 : guestCountRaw;
  const companionNames = cleanText(body.companionNames, 800);
  const dietaryNotes = cleanText(body.dietaryNotes, 1000);
  const message = cleanText(body.message, 1500);
  const sourcePage = cleanText(body.sourcePage || PUBLIC_URL, 255);

  const errors = {};
  if (guestName.length < 2) errors.name = 'Please enter your full name.';
  if (!attendance) errors.attendance = 'Please choose whether you will attend.';
  if (attendance === 'accepts' && (!Number.isInteger(guestCount) || guestCount < 1 || guestCount > 10)) errors.guests = 'Guest count must be between 1 and 10.';
  if (!validateEmail(email)) errors.email = 'Please enter a valid email address.';
  if (Object.keys(errors).length) return json(res, 422, { error: 'Please correct the highlighted information.', fields: errors });

  const token = crypto.randomUUID();
  const result = await pool.query(
    `INSERT INTO rsvp_submissions
      (submission_token, guest_name, email, attendance, guest_count, companion_names, dietary_notes, message, source_page)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
     RETURNING id, submission_token, created_at`,
    [token, guestName, email || null, attendance, guestCount, companionNames || null, dietaryNotes || null, message || null, sourcePage || null]
  );
  const row = result.rows[0];
  const confirmationCode = `IJ-${String(row.id).padStart(4, '0')}-${row.submission_token.slice(0, 4).toUpperCase()}`;
  json(res, 201, { ok: true, confirmationCode, submittedAt: row.created_at });
}

async function adminSummary(req, res) {
  if (!requireAdmin(req, res)) return;
  const result = await pool.query(`
    SELECT COUNT(*)::int AS submissions,
      COUNT(*) FILTER (WHERE attendance='accepts')::int AS attending_responses,
      COUNT(*) FILTER (WHERE attendance='declines')::int AS declining_responses,
      COALESCE(SUM(guest_count) FILTER (WHERE attendance='accepts'),0)::int AS attending_guests
    FROM rsvp_submissions`);
  json(res, 200, result.rows[0]);
}

async function adminList(req, res, url) {
  if (!requireAdmin(req, res)) return;
  const limit = Math.min(Math.max(Number.parseInt(url.searchParams.get('limit') || '200', 10), 1), 1000);
  const attendance = cleanText(url.searchParams.get('attendance'), 16);
  const params = [];
  let where = '';
  if (attendance === 'accepts' || attendance === 'declines') {
    params.push(attendance);
    where = 'WHERE attendance=$1';
  }
  params.push(limit);
  const result = await pool.query(`SELECT id, submission_token, guest_name, email, attendance, guest_count,
      companion_names, dietary_notes, message, source_page, created_at
    FROM rsvp_submissions ${where} ORDER BY created_at DESC LIMIT $${params.length}`, params);
  json(res, 200, { rows: result.rows });
}

function csvCell(value) {
  const s = value === null || value === undefined ? '' : String(value);
  return `"${s.replace(/"/g, '""')}"`;
}

async function adminCsv(req, res) {
  if (!requireAdmin(req, res)) return;
  const result = await pool.query(`SELECT id, guest_name, email, attendance, guest_count, companion_names,
    dietary_notes, message, created_at FROM rsvp_submissions ORDER BY created_at DESC`);
  const headers = ['id','guest_name','email','attendance','guest_count','companion_names','dietary_notes','message','created_at'];
  const lines = [headers.map(csvCell).join(',')];
  for (const row of result.rows) lines.push(headers.map(key => csvCell(row[key])).join(','));
  securityHeaders(res);
  res.writeHead(200, {
    'Content-Type': 'text/csv; charset=utf-8',
    'Content-Disposition': `attachment; filename="ian-jasmin-rsvps-${new Date().toISOString().slice(0,10)}.csv"`,
    'Cache-Control': 'no-store'
  });
  res.end('\uFEFF' + lines.join('\n'));
}

async function serveStatic(req, res, url) {
  let pathname = decodeURIComponent(url.pathname);
  if (pathname === '/') pathname = '/index.html';
  const safePath = path.normalize(pathname).replace(/^(\.\.(\/|\\|$))+/, '');
  const filePath = path.join(PUBLIC_DIR, safePath);
  if (!filePath.startsWith(PUBLIC_DIR)) return json(res, 403, { error: 'Forbidden.' });
  let stat;
  try { stat = await fs.promises.stat(filePath); } catch { return json(res, 404, { error: 'Not found.' }); }
  if (stat.isDirectory()) return json(res, 404, { error: 'Not found.' });
  securityHeaders(res);
  const ext = path.extname(filePath).toLowerCase();
  const cache = ext === '.html' || ext === '.js' ? 'no-cache' : 'public, max-age=86400';
  res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': cache });
  fs.createReadStream(filePath).pipe(res);
}

async function handler(req, res) {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  try {
    if (req.method === 'GET' && url.pathname === '/api/health') {
      await pool.query('SELECT 1');
      return json(res, 200, { ok: true, database: 'connected' });
    }
    if (req.method === 'POST' && url.pathname === '/api/rsvp') return await submitRsvp(req, res);
    if (req.method === 'GET' && url.pathname === '/api/admin/summary') return await adminSummary(req, res);
    if (req.method === 'GET' && url.pathname === '/api/admin/rsvps') return await adminList(req, res, url);
    if (req.method === 'GET' && url.pathname === '/api/admin/rsvps.csv') return await adminCsv(req, res);
    if (req.method !== 'GET' && req.method !== 'HEAD') return json(res, 405, { error: 'Method not allowed.' });
    return await serveStatic(req, res, url);
  } catch (error) {
    console.error(error);
    if (!res.headersSent) json(res, error.status || 500, { error: error.status ? error.message : 'The server could not complete the request.' });
    else res.end();
  }
}

initDatabase()
  .then(() => {
    const server = http.createServer(handler);
    server.listen(PORT, () => console.log(`Ian & Jasmin invitation available on port ${PORT}`));
    const shutdown = async () => { server.close(); await pool.end(); process.exit(0); };
    process.on('SIGTERM', shutdown);
    process.on('SIGINT', shutdown);
  })
  .catch(error => { console.error('Database initialization failed:', error); process.exit(1); });

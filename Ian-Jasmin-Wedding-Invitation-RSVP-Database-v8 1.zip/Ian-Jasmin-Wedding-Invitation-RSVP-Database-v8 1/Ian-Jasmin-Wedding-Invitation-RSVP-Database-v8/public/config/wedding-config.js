/* IAN & JASMIN CONFIGURATION - VERSION 8 WITH DATABASE RSVP */
window.WEDDING_CONFIG = {
  "partnerOne": "Ian",
  "partnerTwo": "Jasmin",
  "monogram": "IJ",
  "date": "02.28.2027",
  "dateISO": "2027-02-28T14:00",
  "time": "2:00 PM",
  "deadline": "RSVP DEADLINE TO BE ANNOUNCED",
  "hashtag": "#JASfoundHerDestIANy",
  "invitation": "With joyful hearts, we invite you to witness the beginning of our forever and celebrate with us as we exchange our vows.",
  "welcome": "We cannot wait to celebrate this beautiful chapter with the people who have filled our lives with love. Your presence will make our day even more meaningful.",
  "verse": "And now these three remain: faith, hope and love. But the greatest of these is love.",
  "verseSource": "1 Corinthians 13:13",
  "story1": "It all started as college classmates, blossomed into friendship, and eventually grew into a love neither could have imagined.",
  "story2": "Through life's beautiful moments and challenges, they found not just love in each other, but a best friend and a partner for life.",
  "story3": "Now, with God at the center of their love, they are ready to begin a new chapter — a lifetime of love, faith, and togetherness. From classmates to friends, from friends to lovers, and now, from lovers to forever.",
  "ceremonyName": "Sacred Heart Seminary and Shrine - Lupit Church",
  "ceremonyTime": "2:00 PM",
  "ceremonyAddress": "Lizares St., Bacolod City",
  "ceremonyMap": "https://maps.app.goo.gl/TqeKPgtikaT3ogMm7",
  "receptionName": "The Sugarland Hotel - Bacolod",
  "receptionTime": "4:00 PM",
  "receptionAddress": "Araneta St., Araneta Ave., Bacolod City",
  "receptionMap": "https://maps.app.goo.gl/uhBurQRGXZs4ibjKA",
  "rsvpEmail": "",
  "attireTitle": "Sage and Emerald Green",
  "attire": "Ladies: Long or mid dresses. Gentlemen: Barong, Suit, long-sleeved or semi-formal wear.",
  "groomParents": "Lanil & Anabelia Montalbo",
  "brideParents": "Ranilo & Hermelinda Mendoza",
  "colors": {
    "emerald": "#123f31",
    "forest": "#285b48",
    "sage": "#9caf88",
    "cream": "#f7f2e8",
    "ivory": "#fffdf8",
    "beige": "#d9cbb7"
  },
  "photos": {
    "hero": "assets/images/photos/hero.jpg",
    "welcome": "assets/images/photos/welcome.jpg",
    "story1": "assets/images/photos/story1.jpg",
    "story2": "assets/images/photos/story2.jpg",
    "story3": "assets/images/photos/story3.jpg",
    "gallery1": "assets/images/photos/gallery-1.svg",
    "gallery2": "assets/images/photos/gallery-2.svg",
    "gallery3": "assets/images/photos/gallery-3.svg",
    "gallery4": "assets/images/photos/gallery-4.svg",
    "gallery5": "assets/images/photos/gallery-5.svg",
    "gallery6": "assets/images/photos/gallery-6.svg",
    "ceremony": "assets/images/photos/Lupit.png",
    "reception": "assets/images/photos/Sugarland.png",
    "attirePrincipal": "assets/images/attire/principal-sponsors.png",
    "attireSecondary": "assets/images/attire/entourage-secondary-attire.png",
    "attireGuests": "assets/images/attire/guest-attire.png"
  },
  "unplugged": "We invite you to be fully present during our ceremony. Kindly keep phones and cameras away until the celebration begins.",
  "gifts": "Your presence and prayers are the greatest gifts. A contribution toward our new chapter would also be warmly appreciated.",
  "footerNote": "Made with love for our favorite people.",
  "timeline": [
    {
      "time": "1:30 PM",
      "title": "Guest Arrival",
      "detail": "Welcome and seating",
      "location": "Welcome and seating",
      "icon": "♙"
    },
    {
      "time": "2:00 PM",
      "title": "Ceremony",
      "detail": "The vows begin",
      "location": "The vows begin",
      "icon": "♢"
    },
    {
      "time": "3:30 PM",
      "title": "Picture Taking",
      "detail": "Picture and get together",
      "location": "Picture and get together",
      "icon": "▣"
    },
    {
      "time": "4:00 PM",
      "title": "Reception",
      "detail": "Dinner and dancing",
      "location": "Dinner and dancing",
      "icon": "♧"
    },
    {
      "time": "9:00 PM",
      "title": "Send-off",
      "detail": "One last cheer",
      "location": "One last cheer",
      "icon": "✦"
    }
  ],
  "entourage": [
    {
      "role": "Parents of the Groom",
      "names": "Lanil Montalbo & Anabelia Montalbo"
    },
    {
      "role": "Parents of the Bride",
      "names": "Ranilo Mendoza & Hermelinda Mendoza"
    },
    {
      "role": "Principal Sponsors",
      "names": "Add names here"
    },
    {
      "role": "Best Man",
      "names": "Juran V. Toledo"
    },
    {
      "role": "Maid of Honor",
      "names": "Jeniffer J. Mendoza"
    },
    {
      "role": "Secondary Sponsors",
      "names": ""
    },
    {
      "role": "Candle",
      "names": "Name 1 & Name 2"
    },
    {
      "role": "Veil",
      "names": "Name 1 & Name 2"
    },
    {
      "role": "Cord",
      "names": "Name 1 & Name 2"
    },
    {
      "role": "Bridesmaids & Groomsmen",
      "names": "Add names here"
    },
    {
      "role": "Flower Girls & Bearers",
      "names": "Add names here"
    }
  ],
  "faq": [
    {
      "question": "How do I RSVP?",
      "answer": "Complete the form above. If an RSVP email is configured, your device will prepare an email for you to send."
    },
    {
      "question": "May I bring a plus one?",
      "answer": "Please follow the number of seats indicated on your personal invitation."
    },
    {
      "question": "What time should I arrive?",
      "answer": "We recommend arriving 30 minutes before the ceremony."
    },
    {
      "question": "Can I take photos?",
      "answer": "The ceremony is unplugged, but we would love your photographs during the reception."
    }
  ],
  "attirePrincipalTitle": "Principal Sponsors",
  "attirePrincipalDetail": "Gentlemen: cream Barong Tagalog with formal black trousers. Ladies: floor-length champagne, nude, beige or soft-gold gowns.",
  "attireSecondaryTitle": "Entourage & Secondary Attire",
  "attireSecondaryDetail": "Ladies may wear sage or emerald formal gowns. Gentlemen may wear gray or sage-toned suits with emerald accents.",
  "attireGuestsTitle": "Guest Attire",
  "attireGuestsDetail": "Please wear semi-formal attire in sage green, emerald, beige or other colors inspired by our wedding palette.",
  "attirePrincipalPalette": "#B39A82,#D8C5AE,#F1E8DE,#E6D8C5,#123F31,#527D67,#9CAF88,#F8F5EE",
  "attireSecondaryPalette": "#123F31,#527D67,#9CAF88,#E9EFE8",
  "attireGuestsPalette": "#123F31,#527D67,#9CAF88,#F7F2E8",
  "rsvpApiUrl": "",
  "rsvpSuccessMessage": "Thank you! Your RSVP has been saved."
};

# Ian & Jasmin Wedding Invitation - Database RSVP Edition

This is the complete deployable wedding website. It preserves the current invitation design and adds a PostgreSQL-backed RSVP API, an admin dashboard, CSV export, validation, rate limiting, and deployment files.

## What changed

The RSVP form now saves responses to PostgreSQL instead of opening an email draft. Each successful response receives a confirmation code.

Stored fields:

- Guest name
- Optional email
- Accepting or declining
- Guest count
- Accompanying guest names
- Dietary/accessibility notes
- Message
- Submission time

The invitation design, envelope opening, curtain transition, monogram, attire guide, venue art, editorial entourage, timeline, editable configuration, and responsive layout are preserved.

## Fastest public deployment: Render Blueprint

1. Create a GitHub repository and upload this entire folder.
2. In Render, select **New > Blueprint**.
3. Connect the repository. Render reads `render.yaml` and creates:
   - A Node web service
   - A PostgreSQL database
   - A generated `ADMIN_KEY`
4. Set `PUBLIC_URL` to the final web-service URL when prompted.
5. Deploy and open the service URL.
6. In the Render service environment settings, copy/save the generated `ADMIN_KEY` securely.
7. Open `https://YOUR-SITE/admin.html` and enter that key to view responses or export CSV.

The application automatically creates the database table and indexes at startup.

> Hosting providers can change their free-tier policies. Verify the current database retention and pricing before sending invitations.

## Local deployment with Docker

1. Install Docker Desktop.
2. Edit `docker-compose.yml` and replace `change-this-admin-key-before-public-use` with a long random secret.
3. Run:

```bash
docker compose up --build
```

4. Invitation: `http://localhost:3000`
5. RSVP dashboard: `http://localhost:3000/admin.html`

Database data is retained in the `wedding_db` Docker volume.

## Local deployment without Docker

Requirements: Node.js 20+ and PostgreSQL 14+.

1. Create a PostgreSQL database.
2. Copy `.env.example` to `.env` and update the values.
3. Export/load the environment variables in your terminal.
4. Install and run:

```bash
npm install
npm start
```

The app runs on `http://localhost:3000` by default.

## Environment variables

- `DATABASE_URL` - PostgreSQL connection string; required.
- `ADMIN_KEY` - long private key for dashboard/API access; required in production.
- `PORT` - web port; defaults to `3000`.
- `PGSSL` - set `disable` for trusted local PostgreSQL; production defaults to TLS.
- `PUBLIC_URL` - optional public invitation URL.

Never put `ADMIN_KEY` in `public/`, `wedding-config.js`, Git, or invitation links.

## RSVP API

### Submit

`POST /api/rsvp`

```json
{
  "name": "Guest Name",
  "email": "guest@example.com",
  "attendance": "Joyfully accepts",
  "guests": 2,
  "companionNames": "Second Guest",
  "dietaryNotes": "No shellfish",
  "message": "Congratulations!"
}
```

### Admin endpoints

Send the admin key in the `x-admin-key` header.

- `GET /api/admin/summary`
- `GET /api/admin/rsvps`
- `GET /api/admin/rsvps?attendance=accepts`
- `GET /api/admin/rsvps.csv`
- `GET /api/health`

## Admin dashboard

Open `/admin.html`, enter `ADMIN_KEY`, and review:

- Response totals
- Accepting and declining counts
- Total attending guests
- Guest details and notes
- Filtered results
- CSV export

The key is kept only in the current browser tab's session storage.

## Edit the invitation

Website content remains in:

`public/config/wedding-config.js`

Photos and illustrations remain in:

`public/assets/images/`

See `INVITATION-EDITING.md` for the existing invitation-editing instructions. For a same-origin deployment, leave `rsvpApiUrl` blank. Set it only if the API is deployed under another compatible URL.

## Database

Schema: `database/schema.sql`

The server executes the idempotent schema at startup. Existing responses are not deleted.

Recommended backups:

```bash
pg_dump "$DATABASE_URL" > wedding-rsvp-backup.sql
```

## Privacy and operations

- Tell guests what RSVP information is collected and why.
- Restrict the admin key to the couple or authorized planner.
- Rotate the key if it is exposed.
- Export/backup responses before changing hosting providers.
- Remove the database after the event when it is no longer needed.

## Important limitation

A central RSVP database requires a running web server and PostgreSQL. Opening `public/index.html` directly still previews the invitation, but cannot store an RSVP. Deploy the complete package for live submissions.

# Public deployment checklist

Before sharing the invitation:

- [ ] PostgreSQL is provisioned and `DATABASE_URL` is configured.
- [ ] `ADMIN_KEY` is at least 24 random characters and stored securely.
- [ ] `/api/health` returns `{"ok":true,"database":"connected"}`.
- [ ] A test RSVP returns a confirmation code.
- [ ] The test RSVP appears in `/admin.html`.
- [ ] CSV export downloads and opens correctly.
- [ ] Wedding date, deadline, venues, map links and contact details are final.
- [ ] The public URL works on a phone using mobile data.
- [ ] Database backups/retention are understood.
- [ ] Guests are given an appropriate privacy notice.
- [ ] Test data is removed or clearly identified before live use.

For Railway or another host, provision PostgreSQL separately and set `DATABASE_URL`, `ADMIN_KEY`, `NODE_ENV=production`, and `PUBLIC_URL` in the service environment.

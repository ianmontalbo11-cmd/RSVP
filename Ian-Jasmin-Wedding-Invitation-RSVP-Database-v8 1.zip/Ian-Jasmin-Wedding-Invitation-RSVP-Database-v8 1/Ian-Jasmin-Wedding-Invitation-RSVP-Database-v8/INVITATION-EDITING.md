# ATTIRE LAYOUT + TRANSPARENT MONOGRAM PACKAGE - VERSION 5.0

# Ian & Jasmin - Editable Digital Wedding Invitation

This package contains a complete wedding invitation website with a premium closed-envelope opening, wax-seal animation, emerald curtains, responsive mobile layout, RSVP form, gallery, story, venues, attire, entourage, timeline and FAQ.

## Open the invitation

Double-click `index.html`. No installation or local server is required.

Keep the folder structure unchanged. `index.html` loads the included local CSS, JavaScript, configuration and images.

## Edit wedding details

Open `config/wedding-config.js` in Notepad, VS Code or another text editor.

Change values inside quotation marks, including:

- Couple names and wedding date
- Countdown date and time
- Invitation, welcome message and Bible verse
- Ceremony and reception names, addresses, times and map links
- RSVP email and deadline
- Attire guidance and wedding hashtag
- Love-story paragraphs
- Timeline
- Entourage names and roles
- FAQs, gift wording and unplugged-ceremony message
- Theme colors
- Image file paths

Save the file, close the invitation if it is open, and reopen `index.html`.

### Countdown date format

Use a date such as:

```text
2027-12-18T15:00:00+08:00
```

## Replace photographs

The editable photographs are in `assets/images/photos/`.

You can either:

1. Replace a placeholder while keeping the same filename, or
2. Add a new JPG, PNG or WebP and update its path under `photos` in `config/wedding-config.js`.

Example:

```javascript
"hero": "assets/images/photos/ian-jasmin-hero.jpg"
```

Recommended sizes:

- Hero/opening: 1920 x 1080 landscape
- Welcome and story portraits: 1200 x 1500 portrait
- Gallery: at least 1200 pixels on the long edge
- Ceremony and reception: 1600 x 900 landscape

## Exact uploaded monogram artwork - visibly used everywhere

The supplied original file is preserved at:

`assets/images/monogram.png`

The website uses this exact PNG for the envelope letter, wax seal, navigation, invitation card and footer. It has not been redrawn, recolored, simplified or replaced.

Do not rename or modify this file unless you intentionally want to replace the monogram everywhere.

## Built-in editor

After opening the invitation, select **Edit Invitation** or the round pencil button.

The editor can change the most common details, colors and photographs. Select **Download updated wedding-config.js**, then replace `config/wedding-config.js` with the downloaded file.

For timeline, entourage and FAQ changes, editing the configuration file directly is easiest.

## RSVP behavior

If `rsvpEmail` is configured, submitting the RSVP form prepares an email in the guest's email application. The guest must press Send.

This static website does not include an online database. For centralized responses, replace the RSVP form with Microsoft Forms, Google Forms or another hosted form.

## Publish online

Upload the entire folder, not only `index.html`.

Options include:

- Netlify Drop
- GitHub Pages
- Your existing website host

The folder structure and relative paths must remain intact.

## Privacy

Only publish details you are comfortable sharing with anyone who receives the invitation link.

## Attire and Motif Guide

The Attire and Motif section includes separate local images for:

- Principal Sponsor
- Secondary Sponsors and Entourage
- Guests

Editable files are in `assets/images/attire/`. Replace a PNG while keeping the same filename, or change its path in `config/wedding-config.js`. The exact original uploaded guide is preserved as `attire-motif-guide-original.png`. Role names and guidance are also editable in the configuration or built-in editor.

## Version 5 attire assets

- `assets/images/attire/principal-sponsors.png`
- `assets/images/attire/entourage-secondary-attire.png`
- `assets/images/attire/guest-attire.png`
- `assets/images/attire/attire-layout-reference.png`

The website has no attire numbering. Each role uses a separate cream bordered card, centered outfit illustration, editable color palette circles and concise guidance. Palette values are comma-separated hex colors in `config/wedding-config.js`.

The active monogram at `assets/images/monogram.png` has a transparent background. The original reference remains at `assets/images/original-monogram-reference.png`.

## Version 5.1 image replacements

This build starts directly from `Ian-Jasmin-Wedding-Invitation-Attire-Layout-v5.zip`. The following local assets were replaced:

- Guest Attire: `assets/images/attire/guest-attire.png`
- Entourage & Secondary Attire: `assets/images/attire/entourage-secondary-attire.png`
- Church venue: `assets/images/photos/Lupit.png`
- Reception venue: `assets/images/photos/Sugarland.png`

All paths remain editable in `config/wedding-config.js`, and the built-in upload controls remain available.

## Version 7 Entourage and Timeline

The Wedding Entourage now uses a centered editorial layout with uppercase categories and clean name groupings. The timeline uses an emerald alternating vertical layout with white icons. Existing data remains in `config/wedding-config.js` under `entourage` and `timeline`. Timeline entries support optional `location` and `icon` fields while preserving `title`, `time` and `detail`.

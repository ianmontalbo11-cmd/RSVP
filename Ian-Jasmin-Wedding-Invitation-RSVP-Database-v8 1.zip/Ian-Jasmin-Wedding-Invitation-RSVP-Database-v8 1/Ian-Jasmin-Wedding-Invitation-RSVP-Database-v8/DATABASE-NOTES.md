# RSVP database notes

- Database: PostgreSQL
- Table: `rsvp_submissions`
- Schema: `database/schema.sql`
- Initialization: automatic at application startup
- Storage: persistent when the PostgreSQL service/volume is persistent
- Exports: `/admin.html` or `GET /api/admin/rsvps.csv`

The package includes the schema but does not contain real guest data. The live database is created by your deployment provider or your local PostgreSQL/Docker environment.
